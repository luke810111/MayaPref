
////////////////////////
///MultiParent SCRIPT///
////////////////////////

This is python script for Autodesk Maya which makes animation with multiple parents dead easy.

content: 
	multiParent.py --- this is the plugin file
	multiParentScript.py --- this is the maya script file


instalation:
	Copy your multiParent.py to your plugin directory. Than load it with plugin manager inside maya. Window->Setting/Preferences->Plugin Manager.

use:
	First select the object you want to animate and than select two objects around which you want to rotate. Than run the script multiParentScript.py. And you are ready to animate.

to do:
	1. Get the thing updated when you set a key. 
	2. And optimalize it, for that I need any attribute which changes only when animation curve get changed.

know bugs: 
	none :D(after 10 min testing :D)


autor: Tomas Skrivan
date: 9.6.2013

licence? Beerware ofcourse! You owe me one!
